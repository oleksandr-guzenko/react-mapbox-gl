module.exports = {
  env: {
    commonjs: true,
    es6: true,
    node: true,
  },
  extends: ['node', 'airbnb-base'],
};
