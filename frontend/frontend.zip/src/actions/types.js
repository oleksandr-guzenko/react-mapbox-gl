export const GET_ALL_INFO = 'GET_ALL_INFO'
export const GET_RESULTS = 'GET_RESULTS'
export const GET_CURRENT = 'GET_CURRENT'